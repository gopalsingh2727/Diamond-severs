const MachineType = require('../../models/MachineType/MachineType')
const connect = require('../../config/mongodb/db');
const verifyToken = require('../../utiles/verifyToken');
const Machine = require('../../models/Machine/machine');




const mongoose = require('mongoose');

// Define MachineType schema directly in the handler
const machineTypeSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  branchId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Branch',
    required: true
  }
}, { timestamps: true });

const MachineType = mongoose.model('MachineType', machineTypeSchema);

// Helper function to connect to MongoDB
const connect = async () => {
  if (mongoose.connection.readyState === 0) {
    try {
      await mongoose.connect(process.env.MONGODB_URI || 'your-mongodb-connection-string');
      console.log('Connected to MongoDB');
    } catch (error) {
      console.error('MongoDB connection error:', error);
      throw error;
    }
  }
};

// Helper function to verify JWT token
const verifyToken = (authHeader) => {
  const jwt = require('jsonwebtoken');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('No token provided');
  }
  
  const token = authHeader.split(' ')[1];
  return jwt.verify(token, process.env.JWT_SECRET || 'your-jwt-secret');
};

// Helper function to check API key
const checkApiKey = (event) => {
  const providedApiKey = event.headers['x-api-key'] || event.headers['X-Api-Key'];
  const validApiKey = process.env.API_KEY || "27infinity.in_5f84c89315f74a2db149c06a93cf4820";
  return providedApiKey === validApiKey;
};

// Helper function for consistent responses with CORS
const respond = (statusCode, data) => {
  return {
    statusCode,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization,x-api-key,X-Api-Key',
      'Access-Control-Allow-Methods': 'POST,OPTIONS,GET,PUT,DELETE',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  };
};

module.exports.createMachineType = async (event) => {
  // Handle preflight OPTIONS request
  if (event.httpMethod === 'OPTIONS') {
    return respond(200, {});
  }

  // Check API key
  if (!checkApiKey(event)) {
    return respond(401, { message: 'Invalid API key' });
  }

  // Connect to database
  await connect();

  try {
    // Parse and verify token
    const authHeader = event.headers.authorization || event.headers.Authorization;
    let user;
    
    try {
      user = verifyToken(authHeader);
    } catch (tokenError) {
      console.error('Token verification failed:', tokenError);
      return respond(401, { message: 'Invalid token' });
    }

    // Check user permissions
    if (!user || (user.role !== 'admin' && user.role !== 'manager')) {
      return respond(403, { message: 'Unauthorized' });
    }

    // Parse request body - handle both payload wrapper and direct structure
    const body = JSON.parse(event.body);
    const { type, description, bodyBranchId } = body.payload || body;

    // Validate required fields
    if (!type) {
      return respond(400, { message: 'Machine type is required' });
    }
    if (!description) {
      return respond(400, { message: 'Description is required' });
    }

    // Determine branchId (admin can specify, manager uses their own)
    const branchId = user.role === 'admin' ? bodyBranchId : user.branchId;
    if (!branchId) {
      return respond(400, { message: 'Branch ID is required' });
    }

    // Validate branchId format
    if (!mongoose.Types.ObjectId.isValid(branchId)) {
      return respond(400, { message: 'Invalid Branch ID format' });
    }

    // Check if machine type already exists (case-insensitive, same branch)
    const exists = await MachineType.findOne({
      type: { $regex: `^${type.trim()}$`, $options: 'i' },
      branchId: new mongoose.Types.ObjectId(branchId),
    });

    if (exists) {
      return respond(400, { message: 'Machine type already exists in this branch' });
    }

    // Create and save new machine type
    const machineType = new MachineType({
      type: type.trim(),
      description: description.trim(),
      branchId: new mongoose.Types.ObjectId(branchId)
    });

    const savedMachineType = await machineType.save();
    
    console.log('Machine type created successfully:', savedMachineType);

    // Return success response
    return respond(201, {
      message: 'Machine type created successfully',
      data: savedMachineType
    });

  } catch (error) {
    console.error('Create Machine Type Error:', error);
    
    // Handle specific MongoDB errors
    if (error.code === 11000) {
      return respond(400, { message: 'Machine type already exists' });
    }
    
    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      return respond(400, { message: 'Validation error', errors: validationErrors });
    }
    
    return respond(500, { 
      message: 'Internal server error',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
    });
  }
};
// ✅ Get All Machine Types
module.exports.getMachineTypes = async (event) => {
  await connect();

  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json'
  };

  try {
    // ✅ API key check
    const apiKey = event.headers['x-api-key'];
    if (!apiKey || apiKey !== process.env.API_KEY) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Invalid API key' }),
      };
    }

    // ✅ Token auth check
    const authHeader = event.headers.authorization || event.headers.Authorization;
    let user;
    try {
      user = verifyToken(authHeader);
    } catch {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ message: 'Invalid or expired token' }),
      };
    }

    if (!user || (user.role !== 'admin' && user.role !== 'manager')) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Unauthorized' }),
      };
    }

    // ✅ Filter machine types based on role
    const filter = user.role === 'manager' ? { branchId: user.branchId } : {};

    const machineTypes = await MachineType.find(filter);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(machineTypes)
    };

  } catch (error) {
    console.error("getMachineTypes error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: error.message })
    };
  }
};

// ✅ Update Machine Type
module.exports.updateMachineType = async (event) => {
  await connect();

  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // ✅ API Key validation
    const apiKey = event.headers['x-api-key'];
    if (!apiKey || apiKey !== process.env.API_KEY) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Invalid API key' })
      };
    }

    // ✅ Auth validation
    const authHeader = event.headers.authorization || event.headers.Authorization;
    let user;
    try {
      user = verifyToken(authHeader);
    } catch (err) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ message: 'Invalid or missing token' })
      };
    }

    const id = event.pathParameters?.id;
    if (!id) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: 'Missing machine type ID' })
      };
    }

    const body = JSON.parse(event.body || '{}');

    const machineType = await MachineType.findById(id);
    if (!machineType) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ message: 'Not found' })
      };
    }

    // ✅ Role check
    if (user.role !== 'admin' && user.branchId !== String(machineType.branchId)) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Unauthorized' })
      };
    }

    // ✅ Update fields safely
    machineType.type = body.type || machineType.type;
    machineType.description = body.description || machineType.description;
    await machineType.save();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(machineType)
    };

  } catch (error) {
    console.error("updateMachineType error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: error.message })
    };
  }
};
// ✅ Delete Machine Type
module.exports.deleteMachineType = async (event) => {
  await connect();

  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // ✅ API key validation
    const apiKey = event.headers['x-api-key'];
    if (!apiKey || apiKey !== process.env.API_KEY) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Invalid API key' })
      };
    }

    // ✅ Token parsing with fallback and error handling
    const authHeader = event.headers.authorization || event.headers.Authorization;
    let user;
    try {
      user = verifyToken(authHeader);
    } catch (err) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ message: 'Invalid or missing token' })
      };
    }

    // ✅ Safe access to ID
    const id = event.pathParameters?.id;
    if (!id) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: 'Missing machine type ID' })
      };
    }

    const machineType = await MachineType.findById(id);
    if (!machineType) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ message: 'Not found' })
      };
    }

    // ✅ Role-based deletion authorization
    if (user.role !== 'admin' && user.branchId !== String(machineType.branchId)) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Unauthorized' })
      };
    }

    await machineType.deleteOne();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: 'Deleted successfully' })
    };

  } catch (error) {
    console.error('deleteMachineType error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: error.message })
    };
  }
};

module.exports.getAllMachineTypesWithMachines = async (event) => {
  await connect();

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  };

  try {
    // ✅ API Key check
    const apiKey = event.headers?.['x-api-key'];
    if (!apiKey || apiKey !== process.env.API_KEY) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Invalid API key' }),
      };
    }

    // ✅ Safe token handling
    const authHeader = event.headers?.authorization || event.headers?.Authorization;
    let user;
    try {
      user = verifyToken(authHeader);
    } catch {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ message: 'Invalid or missing token' }),
      };
    }

    if (!user || (user.role !== 'admin' && user.role !== 'manager')) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ message: 'Unauthorized access' }),
      };
    }

    const filter = user.role === 'manager' ? { branchId: user.branchId } : {};

    const machineTypes = await MachineType.find(filter);

    const results = await Promise.all(
      machineTypes.map(async (type) => {
        const machines = await Machine.find({ machineType: type._id });
        return {
          ...type.toObject(),
          machines,
        };
      })
    );

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(results),
    };

  } catch (err) {
    console.error('Error fetching machine types with machines:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: err.message }),
    };
  }
};